# C++ Garbage Collection

This directory provides an open-source garbage collection library for C++.

The library is under construction, meaning that *all APIs in this directory are incomplete and considered unstable and should not be used*.